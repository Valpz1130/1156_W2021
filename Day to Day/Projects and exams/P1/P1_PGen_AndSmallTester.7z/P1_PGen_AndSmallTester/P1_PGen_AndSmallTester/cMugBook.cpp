#include "FilesProvidedToYou/cMugBook.h"

// These are just "stub" functions.
// So they don't have any code, but allow the program to build. 

cMugBook::cMugBook()
{
}

cMugBook::~cMugBook()
{
}


bool cMugBook::addUser(cPerson thePerson)
{
	// TODO: Add the code here
	return true;
}

bool cMugBook::deleteUser(unsigned int SIN)
{
	// TODO: Add the code here
	return true;
}

bool cMugBook::getUser(unsigned int SIN, cPerson& theUser)
{
	// TODO: Add the code here
	return false;
}

bool cMugBook::updateUserLastName(unsigned int SIN, std::string newLastName)
{
	// TODO: Add the code here
	return true;
}

