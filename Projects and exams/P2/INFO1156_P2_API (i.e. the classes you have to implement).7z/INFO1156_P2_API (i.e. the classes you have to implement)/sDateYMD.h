#ifndef _sDateYMD_HG_
#define _sDateYMD_HG_

struct sDateYMD
{
	sDateYMD(): year(0), month(0), day(0) {};
	unsigned int year;
	unsigned int month;
	unsigned int day;
};

#endif // _sDateYMD_HG_
