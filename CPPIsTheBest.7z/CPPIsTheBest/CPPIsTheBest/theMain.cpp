#include <iostream>  // C++ IO

// Standard Template Library STL
// Everything starts with std:: ("scope" to a "namespace")
// 
// You are welcome to do this, if you'd like.
// But I will not do this.
//using namespace std;


int main()
{
	std::cout << "Hello World" << std::endl;

	return 0;
}


